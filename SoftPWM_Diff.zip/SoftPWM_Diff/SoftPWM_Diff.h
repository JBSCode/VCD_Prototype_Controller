#ifndef _SOFTPWM_DIFF_H_
#define _SOFTPWM_DIFF_H_

#include <Arduino.h>



//------------add this include at the top of your program---------------
#include <avr/pgmspace.h> // enables you to store the gamma table into flash memory instead of Static Ram.

uint8_t const exp_gamma[256] PROGMEM=
{0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,3,3,3,3,3,
4,4,4,4,4,5,5,5,5,5,6,6,6,7,7,7,7,8,8,8,9,9,9,10,10,10,11,11,12,12,12,13,13,14,14,14,15,15,
16,16,17,17,18,18,19,19,20,20,21,21,22,23,23,24,24,25,26,26,27,28,28,29,30,30,31,32,32,33,
34,35,35,36,37,38,39,39,40,41,42,43,44,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,
61,62,63,64,65,66,67,68,70,71,72,73,74,75,77,78,79,80,82,83,84,85,87,89,91,92,93,95,96,98,
99,100,101,102,105,106,108,109,111,112,114,115,117,118,120,121,123,125,126,128,130,131,133,
135,136,138,140,142,143,145,147,149,151,152,154,156,158,160,162,164,165,167,169,171,173,175,
177,179,181,183,185,187,190,192,194,196,198,200,202,204,207,209,211,213,216,218,220,222,225,
227,229,232,234,236,239,241,244,246,249,251,253,254,255
}; // end gamma correction LUT
//-------------------------------------------------------------------------------


/* helper macros */
#define SOFTPWM_DEFINE_PINMODE( CHANNEL, PMODE, PORT, BIT ) \
  template < > \
  inline void pinModeStatic< CHANNEL >( uint8_t const mode ) \
  { \
    if (mode == INPUT) { \
      bitClear(PMODE, BIT); bitClear(PORT, BIT); \
    } else if (mode == INPUT_PULLUP) { \
      bitClear(PMODE, BIT); bitSet(PORT, BIT); \
    } else { \
      bitSet(PMODE, BIT); \
    } \
  }

#define SOFTPWM_DEFINE_CHANNEL( CHANNEL, PMODE, PORT, BIT ) \
  template < > \
  inline void bitWriteStatic< CHANNEL >( bool const value ) \
  { bitWrite( PORT, BIT, value ); } \
  SOFTPWM_DEFINE_PINMODE( CHANNEL, PMODE, PORT, BIT )
  
#define SOFTPWM_DEFINE_CHANNEL_INVERT( CHANNEL, PMODE, PORT, BIT ) \
  template < > \
  inline void bitWriteStatic< CHANNEL >( bool const value ) \
  { bitWrite( PORT, BIT, !value ); } \
  SOFTPWM_DEFINE_PINMODE( CHANNEL, PMODE, PORT, BIT )

#if defined(__AVR_ATtiny24__) || defined(__AVR_ATtiny44__) || defined(__AVR_ATtiny84__)
#define SOFTPWM_DEFINE_OBJECT_WITH_BRIGHTNESS_LEVELS( CHANNEL_CNT, BRIGHTNESS_LEVELS ) \
  CSoftPWM< CHANNEL_CNT, BRIGHTNESS_LEVELS > SoftPWM; \
  ISR(TIM1_COMPA_vect) { interrupts(); SoftPWM.update(); }
#else
#define SOFTPWM_DEFINE_OBJECT_WITH_BRIGHTNESS_LEVELS( CHANNEL_CNT, BRIGHTNESS_LEVELS ) \
  CSoftPWM< CHANNEL_CNT, BRIGHTNESS_LEVELS > SoftPWM; \
  ISR(TIMER1_COMPA_vect) { interrupts(); SoftPWM.update(); }
#endif

#define SOFTPWM_DEFINE_OBJECT( CHANNEL_CNT ) \
  SOFTPWM_DEFINE_OBJECT_WITH_BRIGHTNESS_LEVELS( CHANNEL_CNT, 0 )

#define SOFTPWM_DEFINE_EXTERN_OBJECT_WITH_BRIGHTNESS_LEVELS( CHANNEL_CNT, BRIGHTNESS_LEVELS ) \
  extern CSoftPWM< CHANNEL_CNT, BRIGHTNESS_LEVELS > SoftPWM;
  
#define SOFTPWM_DEFINE_EXTERN_OBJECT( CHANNEL_CNT ) \
  SOFTPWM_DEFINE_EXTERN_OBJECT_WITH_BRIGHTNESS_LEVELS( CHANNEL_CNT, 0 )

/* here comes the magic @o@ */
template < int channel > inline void bitWriteStatic( bool value ) {}
template < int channel > inline void pinModeStatic( uint8_t mode ) {}

template < int channel >
struct bitWriteStaticExpander
{
  void operator() ( bool value ) const
  {
    bitWriteStatic< channel >( value );
    bitWriteStaticExpander< channel - 1 >()( value );
  }

  void operator() ( uint8_t const &count, uint8_t const * const &channels ) const
  {
    bitWriteStatic< channel >( (count + channel) < channels[ channel ] );
    bitWriteStaticExpander< channel - 1 >()( count, channels );
  }
};

template < >
struct bitWriteStaticExpander< -1 >
{
  void operator() ( bool ) const {}
  void operator() ( uint8_t const &, uint8_t const * const & ) const {}
};

template < int channel >
struct pinModeStaticExpander
{
  void operator() ( uint8_t const mode ) const
  {
    pinModeStatic< channel >( mode );
    pinModeStaticExpander< channel - 1 >()( mode );
  }
};

template < >
struct pinModeStaticExpander< -1 >
{
  void operator() ( uint8_t const mode ) const {}
};

template < int num_channels, int num_brightness_levels >
class CSoftPWM
{
public:
  void begin(long hertz)
  {
    asm volatile ("/************ pinModeStaticExpander begin ************/");
    uint8_t oldSREG = SREG;
    noInterrupts();
    pinModeStaticExpander< num_channels - 1 >()( OUTPUT );
    SREG = oldSREG;
    asm volatile ("/************ pinModeStaticExpander end ************/");

    /* the setup of timer1 is stolen from ShiftPWM :-P
     * http://www.elcojacobs.com/shiftpwm/ */
    asm volatile ("/************ timer setup begin ************/");
    TCCR1A = 0b00000000;
    TCCR1B = 0b00001001;
    OCR1A = (F_CPU - hertz * brightnessLevels() / 2) / (hertz * brightnessLevels());
    bitSet(TIMSK1,OCIE1A);
    asm volatile ("/************ timer setup end ************/");

    _count = 0;
  }

  void set( int channel_idx, uint8_t value )
  {
    _channels[ channel_idx ] = value;
  }

  size_t size() const { return num_channels; }
  int brightnessLevels() const { return num_brightness_levels ? num_brightness_levels : 256; }

  void allOff()
  {
    asm volatile ( "/********** CSoftPWM::allOff() begin **********/" );
    uint8_t oldSREG = SREG;
    noInterrupts();
    for ( int i = 0; i < num_channels; ++i )
      _channels[i] = 0;
    bitWriteStaticExpander< num_channels - 1 >()( false );
    SREG = oldSREG;
    asm volatile ( "/********** CSoftPWM::allOff() end **********/" );
  }
  
  /* this function cannot be private because the ISR uses it, and I have
   * no idea about how to make friends with ISR. :-( */
  void update() __attribute__((always_inline))
  {
    asm volatile ( "/********** CSoftPWM::update() begin **********/" );
    uint8_t count = _count;
    bitWriteStaticExpander< num_channels - 1 >()( count, _channels );
    ++_count;
    if ( _count == brightnessLevels() )
      _count = 0;
    asm volatile ( "/********** CSoftPWM::update() end **********/" );
  }

  /* this function is stolen from ShiftPWM :-P
   * http://www.elcojacobs.com/shiftpwm/ */
  void printInterruptLoad()
  {
    #ifdef __DEBUG_SOFTPWM__
    unsigned long time1, time2;

    bitSet( TIMSK1, OCIE1A ); // enable interrupt
    time1 = micros();
    delayMicroseconds( 5000 );
    time1 = micros() - time1;

    bitClear( TIMSK1, OCIE1A ); // disable interrupt
    time2 = micros();
    delayMicroseconds( 5000 );
    time2 = micros() - time2;

    double load = static_cast< double >(time1 - time2) / time1;
    double interrupt_frequency = static_cast< double >(F_CPU) / (OCR1A + 1);
    double cycles_per_interrupt = load * F_CPU / interrupt_frequency;

    Serial.println( F("SoftPWM::printInterruptLoad():") );
    Serial.print( F("  Load of interrupt: ") );
    Serial.println( load, 10 );
    Serial.print( F("  Clock cycles per interrupt: ") );
    Serial.println( cycles_per_interrupt );
    Serial.print( F("  Interrupt frequency: ") );
    Serial.print( interrupt_frequency );
    Serial.println( F(" Hz") );
    Serial.print( F("  PWM frequency: ") );
    Serial.print( interrupt_frequency / brightnessLevels() );
    Serial.println( F(" Hz") );
    Serial.print( F("  Brightness levels: ") );
    Serial.println( brightnessLevels() );
    
    bitSet( TIMSK1, OCIE1A ); // enable interrupt again
    #endif
  }

private:
  static void _timerCallback();

  uint8_t _channels[ num_channels ];
  uint8_t _count;
};

#endif
